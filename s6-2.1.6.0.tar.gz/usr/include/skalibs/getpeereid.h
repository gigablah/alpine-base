/* ISC license. */

#ifndef GETPEEREID_H
#define GETPEEREID_H

#include <sys/types.h>

extern int getpeereid (int, uid_t *, gid_t *) ;

#endif
